document.addEventListener("DOMContentLoaded", function (event) {
    console.log("test");
});