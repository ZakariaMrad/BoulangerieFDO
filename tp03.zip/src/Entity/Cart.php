<?php
namespace App\Entity;

use App\Core\Constants;
use App\Entity\Purchase;

class Cart
{
    private $purchases = [];
    private $BASEQUANTITYTOADD =1;
    private $subTotalPrice=0;
    private $tps=0;
    private $tvq=0;
    private $totalPrice=0;

    public function __construct(){
        $this->purchases=[];
    }

    public function add(Product $product):string //true if is added, false if updated
    {
        $purchaseId = $this->ContainsPurchases($product->getIdProduct()); //If is -1, then purchase is not in array

        if ($purchaseId ==-1) {
            $purchase = new Purchase($product);
            $this->purchases[]=$purchase;
            return "added";
        } else {
            $baseQantity = $this->purchases[$purchaseId]->getQuantity();
            $this->purchases[$purchaseId]->setQuantity($baseQantity+$this->BASEQUANTITYTOADD);
            return "updated";
        }
    }

    public function update($post)
    {
        $inpQuantity = $post['inpQuantity'];
        for ($i=0; $i < count($inpQuantity); $i++) { 
            $this->purchases[$i]->setQuantity($inpQuantity[$i]);
        }
    }

    public function removeOne($idPurchase){
        array_splice($this->purchases,$idPurchase,1);
    }
    public function getPurchases(){
        return $this->purchases;
    }
    public function getSubTotalPrice(){
        $this->subTotalPrice=array_reduce($this->purchases, function($sum, $item)
        {
            return $sum + $item->getPurchasePrice();
        });
        return $this->subTotalPrice;
    }
    public function getTps(){
        $this->tps = $this->subTotalPrice*Constants::TPS;
        return $this->tps;
    }
    public function getTvq(){
        $this->tvq = $this->subTotalPrice*Constants::TVQ;
        return $this->tvq;
    }
    public function getShippingCost(){
        if ($this->subTotalPrice>0) {
            return Constants::SHIPPING_COST;
        }
        return 0;
    }
    public function getTotalPrice(){
        return $this->subTotalPrice+$this->tps+$this->tvq+Constants::SHIPPING_COST;
    }

    private function ContainsPurchases($idProduct): int
    {
        for ($i = 0; $i < count($this->purchases); $i++) {
            if ($this->purchases[$i]->getProduct()->getIdProduct() == $idProduct) {
                return $i;
            }
        }
        return -1;
    }
}