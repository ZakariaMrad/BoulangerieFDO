INSERT INTO `categories` (`idCategory`, `name`) VALUES
(1, 'Baklava and Related Pastries'),
(2, 'Maamoul and Related Pastries'),
(3, 'Cheese and Cream Pastries'),
(4, 'Nuts and Syrup Pastries'),
(5, 'Fried Pastries'),
(6, 'Savory Pastries'),
(7, 'Products');