<?php
namespace App\Entity;

class Purchase{
    private $quantity;
    private $purchasePrice;
    private $product;

    public function __construct(Product $product){
        $this->quantity = 1;
        $this->purchasePrice = $product->getPrice();
        $this->product = $product;
    }

    public function setQuantity($quantity){
        $this->quantity=$quantity;
        return $this->quantity;
    }

    public function getProduct():Product{
        return $this->product;
    }
    public function getPurchasePrice(){
        return $this->purchasePrice*$this->quantity;
    }
    public function getQuantity(){
        return $this->quantity;
    }

}